
Patrz: /home/furas/projekty/firefox-extensions/README.md
